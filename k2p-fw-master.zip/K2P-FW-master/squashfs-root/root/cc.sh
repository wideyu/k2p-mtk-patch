rm -f /tmp/luci-indexcache
rm -f /tmp/luci-modulecache/*