insmod /lib/modules/ralink/hw_nat.ko
iwpriv ra0 set hw_nat_register=1
iwpriv rax0 set hw_nat_register=1

