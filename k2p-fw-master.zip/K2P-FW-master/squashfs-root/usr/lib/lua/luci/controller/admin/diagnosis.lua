module("luci.controller.admin.diagnosis",package.seeall)function index()entry({"pc","diagnose.htm"},template("pc/diagnose")).leaf=true
entry({"h5","diagnose.htm"},template("h5/diagnose")).leaf=true
end
